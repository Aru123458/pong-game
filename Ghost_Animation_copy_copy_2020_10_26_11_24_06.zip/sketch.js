var ghost, ghostimg

function preload() {
ghostimg= loadAnimation("ghost1.png", "ghost2.png", "ghost3.png");
}

function setup(){
createCanvas(400,400)
ghost=createSprite(200,200,40,50)
ghost.addAnimation("ghostrun",ghostimg)
ghost.scale=0.8

}

function draw(){
  background ("black")
  
  drawSprites();
  
}